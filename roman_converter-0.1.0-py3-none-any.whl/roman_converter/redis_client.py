import redis
import os

def get_redis_client():
    redis_host = os.getenv("REDIS_HOST", "localhost")
    client = redis.Redis(
        host=redis_host,
        port=6379,
        db=0,
        decode_responses=True
    )
    try:
        client.ping()
    except redis.ConnectionError as e:
        print(f"Warning: Could not connect to Redis - {e}")
    return client