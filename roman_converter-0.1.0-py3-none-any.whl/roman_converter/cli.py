import argparse
from roman_converter.V3roman_con import RomanNumeralConverter
from icecream import ic
from roman_converter.redis_client import get_redis_client

def main():
    redis_client = get_redis_client()
    parser = argparse.ArgumentParser(description="Convert between Roman and Arabic numerals.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--roman', '-r', help='Convert Roman numeral to Arabic number (e.g. XIV)')
    group.add_argument('--arabic', '-a', type=int, help='Convert Arabic number to Roman numeral (e.g. 1990)')

    args = parser.parse_args()
    converter = RomanNumeralConverter()

    if args.roman:
        result = converter.roman_to_arabic(args.roman)
        ic(f"{args.roman.upper()} → {result}")
    elif args.arabic:
        try:
            result = converter.arabic_to_roman(args.arabic)
            ic(f"{args.arabic} → {result}")
        except ValueError as e:
            ic(f"Error: {e}")

if __name__ == "__main__":
    main()
##Add if name__ == "__main__":