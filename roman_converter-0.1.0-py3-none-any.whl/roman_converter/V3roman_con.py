from icecream import ic

class RomanNumeralConverter:
    def __init__(self):
        self.roman_to_arabic_map = {
            'I': 1, 'V': 5, 'X': 10, 'L': 50,
            'C': 100, 'D': 500, 'M': 1000
        }
        self.arabic_to_roman_map = [
            (1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'),
            (100, 'C'), (90, 'XC'), (50, 'L'), (40, 'XL'),
            (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I')
        ]

    def roman_to_arabic(self, roman):
        roman = roman.upper()
        ic(roman)  # Show the input after uppercasing
        total = 0
        prev_value = 0

        for char in reversed(roman):
            value = self.roman_to_arabic_map.get(char, 0)
            ic(char, value, prev_value)  # Trace each character and its value
            if value < prev_value:
                total -= value
                ic(f"Subtracting: {value} → total = {total}")
            else:
                total += value
                ic(f"Adding: {value} → total = {total}")
            prev_value = value

        ic(total)  # Final result
        return total

    def arabic_to_roman(self, number):
        if not (0 < number < 4000):
            raise ValueError("Number out of range (must be 1..3999)")

        result = ''
        ic(number)  # Initial input
        for arabic, roman in self.arabic_to_roman_map:
            while number >= arabic:
                ic(arabic, roman, number)  # Show match and state before applying
                result += roman
                number -= arabic
                ic(result, number)  # Show partial result and remaining value

        ic(result)  # Final Roman numeral
        return result